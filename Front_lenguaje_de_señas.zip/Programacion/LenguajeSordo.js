let lData    = ["Hola","Adios"];
window.addEventListener('load',CargaHtml,false);

// Carga Todos los Datos 
async function CargaHtml()
{   document.querySelector("#Menu").onclick=function(){ verMenu();};
    document.querySelector("#oMenu").onclick=function(){ ocultarMenu();};
    document.querySelector("#sClick").onclick=function(){ verPrincipal();};
    document.querySelector("#nClick").onclick=function(){ verPrincipal();};
    document.querySelectorAll(".Opcion")[0].onclick=function(){  verPrincipal();};
    document.querySelectorAll(".Opcion")[1].onclick=function(){  verPrincipal();};
    document.querySelector("#Volver").onclick=function(){ verInicio();};
    document.querySelector("#fVolver").onclick=function(){ verPrincipal();};
    document.querySelectorAll(".Modulo")[1].onclick=function(){  verFundamentales();};
}

// Muestra el menu principal
function verMenu()
{   document.querySelector(".MenuPpal").style.pointerEvents="auto";
    document.querySelector(".MenuPpal").style.opacity="1"; 
    document.querySelector(".Menu").style.display="inline";
}

// Oculta el menu principal
function ocultarMenu()
{   document.querySelector(".MenuPpal").style.pointerEvents="none";
    document.querySelector(".MenuPpal").style.opacity="0"; 
    document.querySelector(".Menu").style.display="none";
}

// Muestra la pantalla principal para escoger el modulo de conversación
function  verPrincipal()
{   ocultarMenu();
    document.querySelector(".Inicio").style.display="none";
    document.querySelector(".Principal").style.display="inline";
    document.querySelector(".Fundamental").style.display="none";
}

// Muestra la pantalla de presentación
function verInicio()
{   document.querySelector(".Inicio").style.display="inline";
    document.querySelector(".Principal").style.display="none";

}

// Muestra lo que hay en el modulo de Fundamentales
function verFundamentales()
{   document.querySelector(".Fundamental").style.display="inline";
    document.querySelector(".Muestra").style.display="none";
    document.querySelector(".Palabras").innerHTML="";
    document.querySelector(".Principal").style.display="none";
    for(i=0; i<lData.length;i++)
    {   let wDiv=document.createElement("div");
        wDiv.className="Palabra";
        wDiv.id=lData[i];
        wDiv.onclick=function(){verVideo(this);}
            let wSpan= document.createElement("span");
            wSpan.innerText=lData[i];
        wDiv.appendChild(wSpan);
        document.querySelector(".Palabras").appendChild(wDiv);
    }
}

//Muestra el video dependiendo de la palabra
function verVideo(wDiv)
{   let wId=wDiv.id +".mp4";
    document.querySelector("#idP").innerText=wDiv.id;
    document.querySelector(".Fundamental").style.display="none";
    document.querySelector(".Muestra").style.display="inline";
    document.querySelector("#mVolver").onclick=function(){ verFundamentales();}
    document.querySelector("#Reproducir").src=wId;
    document.querySelector("#Reproducir").play();
}
